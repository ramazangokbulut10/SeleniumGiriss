package day04;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

public class odev {
    //1-C01_TekrarTesti isimli bir class olusturun  2- https://www.amazon.com/ adresine gidin  3- Browseri tam sayfa yapin
    //Sayfayi “refresh” yapin
    //Sayfa basliginin “Spend less” ifadesi icerdigini test edin
    //Gift Cards sekmesine basin
    //Birthday butonuna basin
    //Best Seller bolumunden ilk urunu tiklayin  9- Gift card details’den 25 $’i secin
    //10-Urun ucretinin 25$ oldugunu test edin
    //10-Sayfayi kapatin

    public static void main(String[] args) {
    }


}
